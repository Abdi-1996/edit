import XCTest
@testable import EditFlow

final class SpeedCurveTests: XCTestCase {
    func testLinearInterpolation() {
        let curve = SpeedCurve(points: [
            SpeedPoint(position: 0, speed: 0.5),
            SpeedPoint(position: 1, speed: 2.5)
        ])
        XCTAssertEqual(curve.speed(at: 0), 0.5, accuracy: 0.001)
        XCTAssertEqual(curve.speed(at: 0.5), 1.5, accuracy: 0.001)
        XCTAssertEqual(curve.speed(at: 1), 2.5, accuracy: 0.001)
    }

    func testPointsAreSortedAndEndpointsPinned() {
        let curve = SpeedCurve(points: [
            SpeedPoint(position: 0.75, speed: 2),
            SpeedPoint(position: 0.25, speed: 0.5),
            SpeedPoint(position: 0.5, speed: 1)
        ])
        XCTAssertEqual(curve.points.first?.position, 0)
        XCTAssertEqual(curve.points.last?.position, 1)
        XCTAssertEqual(curve.points.map(\.position), curve.points.map(\.position).sorted())
    }

    func testInteriorPointCannotCrossNeighbours() {
        var curve = SpeedCurve(points: [
            SpeedPoint(position: 0, speed: 1),
            SpeedPoint(position: 0.5, speed: 1),
            SpeedPoint(position: 1, speed: 1)
        ])
        let id = curve.points[1].id
        curve.update(id: id, position: 2, speed: 20)
        XCTAssertLessThan(curve.points[1].position, 1)
        XCTAssertEqual(curve.points[1].speed, 8, accuracy: 0.001)
    }

    func testTemplateLibraryIsUsable() {
        XCTAssertGreaterThanOrEqual(EditTemplate.builtIn.count, 4)
        XCTAssertTrue(EditTemplate.builtIn.allSatisfy { $0.curve.points.count >= 2 })
    }
}

