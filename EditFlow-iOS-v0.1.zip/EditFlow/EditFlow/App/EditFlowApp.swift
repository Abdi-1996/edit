import SwiftUI

@main
struct EditFlowApp: App {
    @StateObject private var editor = EditorViewModel()

    var body: some Scene {
        WindowGroup {
            EditorView()
                .environmentObject(editor)
                .preferredColorScheme(.dark)
        }
    }
}

