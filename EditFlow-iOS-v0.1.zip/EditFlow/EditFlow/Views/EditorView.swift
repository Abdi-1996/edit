import PhotosUI
import SwiftUI

struct EditorView: View {
    @EnvironmentObject private var editor: EditorViewModel
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass
    @State private var photoItems: [PhotosPickerItem] = []
    @State private var showExport = false

    var body: some View {
        ZStack {
            background

            GeometryReader { proxy in
                VStack(spacing: 10) {
                    topBar

                    if horizontalSizeClass == .regular && proxy.size.width >= 850 {
                        HStack(spacing: 12) {
                            EditorMainColumn()
                                .frame(maxWidth: .infinity)
                            EditorInspectorView()
                                .frame(width: min(390, proxy.size.width * 0.36))
                        }
                    } else {
                        ScrollView {
                            VStack(spacing: 12) {
                                EditorMainColumn()
                                EditorInspectorView()
                                    .frame(minHeight: 390)
                            }
                        }
                        .scrollIndicators(.hidden)
                    }
                }
                .padding(.horizontal, horizontalSizeClass == .regular ? 16 : 10)
                .padding(.bottom, 8)
            }
        }
        .sheet(isPresented: $showExport) {
            ExportSheet()
                .environmentObject(editor)
        }
        .alert("EditFlow", isPresented: Binding(
            get: { editor.message != nil },
            set: { if !$0 { editor.dismissMessage() } }
        )) {
            Button("OK", role: .cancel) { editor.dismissMessage() }
        } message: {
            Text(editor.message ?? "")
        }
        .onChange(of: photoItems) { _, newItems in
            guard !newItems.isEmpty else { return }
            Task {
                var imported: [ImportedMovie] = []
                for item in newItems {
                    if let movie = try? await item.loadTransferable(type: ImportedMovie.self) {
                        imported.append(movie)
                    }
                }
                await editor.importMovies(imported)
                photoItems = []
            }
        }
    }

    private var background: some View {
        ZStack {
            EditFlowTheme.background
            RadialGradient(
                colors: [EditFlowTheme.accent.opacity(0.18), .clear],
                center: .topTrailing,
                startRadius: 0,
                endRadius: 520
            )
            RadialGradient(
                colors: [EditFlowTheme.accentPink.opacity(0.09), .clear],
                center: .bottomLeading,
                startRadius: 0,
                endRadius: 430
            )
        }
        .ignoresSafeArea()
    }

    private var topBar: some View {
        HStack(spacing: 12) {
            HStack(spacing: 9) {
                ZStack {
                    RoundedRectangle(cornerRadius: 10)
                        .fill(
                            LinearGradient(
                                colors: [EditFlowTheme.accent, EditFlowTheme.accentPink],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                        )
                        .frame(width: 34, height: 34)
                    Image(systemName: "waveform.path.ecg.rectangle.fill")
                        .font(.system(size: 16, weight: .bold))
                }
                VStack(alignment: .leading, spacing: 0) {
                    Text("EditFlow")
                        .font(.headline.bold())
                    Text(editor.project.name)
                        .font(.caption2)
                        .foregroundStyle(EditFlowTheme.textSecondary)
                }
            }

            Spacer()

            if editor.isImporting {
                ProgressView().controlSize(.small)
            }

            PhotosPicker(selection: $photoItems, maxSelectionCount: 20, matching: .videos) {
                Label("Видео", systemImage: "plus")
                    .font(.caption.bold())
                    .padding(.horizontal, 12)
                    .padding(.vertical, 9)
                    .background(.white.opacity(0.08), in: Capsule())
            }
            .buttonStyle(.plain)

            Button {
                showExport = true
            } label: {
                Label("Экспорт", systemImage: "arrow.up.right")
                    .font(.caption.bold())
                    .padding(.horizontal, 12)
                    .padding(.vertical, 9)
                    .background(EditFlowTheme.accent, in: Capsule())
            }
            .buttonStyle(.plain)
            .disabled(editor.project.clips.isEmpty)
        }
        .padding(.vertical, 8)
    }
}

private struct EditorMainColumn: View {
    @EnvironmentObject private var editor: EditorViewModel

    var body: some View {
        VStack(spacing: 10) {
            ZStack {
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .fill(Color.black.opacity(0.8))

                if editor.selectedClip != nil {
                    PlayerSurface(player: editor.player)
                        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                        .padding(5)
                } else {
                    ContentUnavailableView(
                        "Добавьте первый клип",
                        systemImage: "play.rectangle.on.rectangle",
                        description: Text("Нажмите «Видео» вверху")
                    )
                }

                if let clip = editor.selectedClip {
                    VStack {
                        HStack {
                            Text(clip.look.title)
                                .font(.caption2.bold())
                                .padding(.horizontal, 9)
                                .padding(.vertical, 5)
                                .background(.black.opacity(0.55), in: Capsule())
                            Spacer()
                            Text(String(format: "%.2f×", clip.speedCurve.speed(at: editor.selectedProgress)))
                                .font(.caption.monospacedDigit().bold())
                                .foregroundStyle(EditFlowTheme.cyan)
                                .padding(.horizontal, 9)
                                .padding(.vertical, 5)
                                .background(.black.opacity(0.55), in: Capsule())
                        }
                        Spacer()
                    }
                    .padding(14)
                }
            }
            .aspectRatio(16 / 9, contentMode: .fit)
            .frame(maxHeight: 430)
            .overlay {
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .stroke(.white.opacity(0.08))
            }

            TransportView()
                .padding(.horizontal, 6)

            TimelineView()
        }
    }
}
