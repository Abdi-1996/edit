import SwiftUI

struct ExportSheet: View {
    @EnvironmentObject private var editor: EditorViewModel
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                ZStack {
                    Circle()
                        .fill(EditFlowTheme.accent.opacity(0.18))
                        .frame(width: 96, height: 96)
                    Image(systemName: editor.exportedURL == nil ? "arrow.up.forward.app.fill" : "checkmark.circle.fill")
                        .font(.system(size: 42))
                        .foregroundStyle(editor.exportedURL == nil ? EditFlowTheme.accent : EditFlowTheme.cyan)
                }

                VStack(spacing: 5) {
                    Text(editor.exportedURL == nil ? "Экспорт эдита" : "Видео готово")
                        .font(.title2.bold())
                    Text("Ориентация и частота кадров сохраняются из исходного видео.")
                        .font(.caption)
                        .foregroundStyle(EditFlowTheme.textSecondary)
                        .multilineTextAlignment(.center)
                }

                Picker("Качество", selection: $editor.exportQuality) {
                    ForEach(ExportQuality.allCases) { quality in
                        Text(quality.rawValue).tag(quality)
                    }
                }
                .pickerStyle(.segmented)

                if editor.isExporting {
                    VStack(spacing: 10) {
                        ProgressView()
                        Text("Применяю speed ramp и цветовой стиль…")
                            .font(.caption)
                            .foregroundStyle(EditFlowTheme.textSecondary)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(18)
                    .background(.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 14))
                }

                if let url = editor.exportedURL {
                    ShareLink(item: url) {
                        Label("Поделиться видео", systemImage: "square.and.arrow.up")
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 12)
                    }
                    .buttonStyle(.plain)
                    .background(EditFlowTheme.accent, in: RoundedRectangle(cornerRadius: 12))

                    Button {
                        Task { await editor.saveExportToPhotos() }
                    } label: {
                        Label("Сохранить в Фото", systemImage: "photo.badge.arrow.down")
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 12)
                    }
                    .buttonStyle(.plain)
                    .background(.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 12))
                } else {
                    Button {
                        Task { await editor.export() }
                    } label: {
                        Label("Начать экспорт", systemImage: "sparkles.tv.fill")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 13)
                    }
                    .buttonStyle(.plain)
                    .background(
                        LinearGradient(
                            colors: [EditFlowTheme.accent, EditFlowTheme.accentPink],
                            startPoint: .leading,
                            endPoint: .trailing
                        ),
                        in: RoundedRectangle(cornerRadius: 12)
                    )
                    .disabled(editor.project.clips.isEmpty || editor.isExporting)
                }
                Spacer()
            }
            .padding(24)
            .background(EditFlowTheme.background.ignoresSafeArea())
            .navigationTitle("Экспорт")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Готово") { dismiss() }
                }
            }
        }
        .presentationDetents([.medium, .large])
    }
}

