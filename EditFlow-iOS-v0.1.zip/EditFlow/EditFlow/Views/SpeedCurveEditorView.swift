import Foundation
import SwiftUI

struct SpeedCurveEditorView: View {
    @Binding var curve: SpeedCurve
    var currentProgress: Double
    @State private var selectedPointID: UUID?

    private let graphPadding: CGFloat = 16

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text("Speed Ramp")
                        .font(.headline)
                    Text("Перетаскивайте точки · двойной тап добавляет")
                        .font(.caption2)
                        .foregroundStyle(EditFlowTheme.textSecondary)
                }
                Spacer()
                Text(String(format: "%.2f×", curve.speed(at: currentProgress)))
                    .font(.system(.callout, design: .rounded, weight: .bold))
                    .foregroundStyle(EditFlowTheme.cyan)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 6)
                    .background(EditFlowTheme.cyan.opacity(0.12), in: Capsule())
            }

            GeometryReader { proxy in
                let size = proxy.size
                ZStack {
                    Canvas { context, canvasSize in
                        drawGrid(context: context, size: canvasSize)
                        drawCurve(context: context, size: canvasSize)
                        drawPlayhead(context: context, size: canvasSize)
                    }

                    ForEach(curve.points) { point in
                        Circle()
                            .fill(point.id == selectedPointID ? EditFlowTheme.accentPink : .white)
                            .frame(width: 14, height: 14)
                            .shadow(color: EditFlowTheme.accent.opacity(0.8), radius: 7)
                            .position(position(for: point, in: size))
                            .gesture(
                                DragGesture(minimumDistance: 0, coordinateSpace: .named("speedGraph"))
                                    .onChanged { value in
                                        selectedPointID = point.id
                                        var updated = curve
                                        updated.update(
                                            id: point.id,
                                            position: progress(fromX: value.location.x, width: size.width),
                                            speed: speed(fromY: value.location.y, height: size.height)
                                        )
                                        curve = updated
                                    }
                            )
                            .contextMenu {
                                Button("Удалить точку", systemImage: "trash", role: .destructive) {
                                    var updated = curve
                                    updated.removePoint(id: point.id)
                                    curve = updated
                                }
                            }
                    }
                }
                .contentShape(Rectangle())
                .coordinateSpace(name: "speedGraph")
                .gesture(
                    SpatialTapGesture(count: 2, coordinateSpace: .named("speedGraph"))
                        .onEnded { value in
                            var updated = curve
                            updated.addPoint(
                                position: progress(fromX: value.location.x, width: size.width),
                                speed: speed(fromY: value.location.y, height: size.height)
                            )
                            curve = updated
                        }
                )
            }
            .frame(minHeight: 170, idealHeight: 210, maxHeight: 250)
            .background(EditFlowTheme.background.opacity(0.8), in: RoundedRectangle(cornerRadius: 14))
            .overlay(alignment: .leading) {
                VStack {
                    Text("8×")
                    Spacer()
                    Text("1×")
                    Spacer()
                    Text("0.1×")
                }
                .font(.system(size: 8, weight: .medium, design: .monospaced))
                .foregroundStyle(.white.opacity(0.38))
                .padding(.vertical, 10)
                .padding(.leading, 4)
            }

            HStack(spacing: 8) {
                SpeedPresetButton(label: "0.25×", speed: 0.25, curve: $curve)
                SpeedPresetButton(label: "0.5×", speed: 0.5, curve: $curve)
                SpeedPresetButton(label: "1×", speed: 1, curve: $curve)
                SpeedPresetButton(label: "2×", speed: 2, curve: $curve)
                SpeedPresetButton(label: "4×", speed: 4, curve: $curve)
            }
        }
    }

    private func drawGrid(context: GraphicsContext, size: CGSize) {
        var path = Path()
        for index in 0...4 {
            let x = graphPadding + ((size.width - graphPadding * 2) * CGFloat(index) / 4)
            path.move(to: CGPoint(x: x, y: graphPadding))
            path.addLine(to: CGPoint(x: x, y: size.height - graphPadding))
        }
        for index in 0...4 {
            let y = graphPadding + ((size.height - graphPadding * 2) * CGFloat(index) / 4)
            path.move(to: CGPoint(x: graphPadding, y: y))
            path.addLine(to: CGPoint(x: size.width - graphPadding, y: y))
        }
        context.stroke(path, with: .color(.white.opacity(0.075)), lineWidth: 0.7)
    }

    private func drawCurve(context: GraphicsContext, size: CGSize) {
        guard let first = curve.points.first else { return }
        var path = Path()
        path.move(to: position(for: first, in: size))
        for point in curve.points.dropFirst() {
            path.addLine(to: position(for: point, in: size))
        }
        context.stroke(
            path,
            with: .linearGradient(
                Gradient(colors: [EditFlowTheme.cyan, EditFlowTheme.accent, EditFlowTheme.accentPink]),
                startPoint: CGPoint(x: 0, y: size.height),
                endPoint: CGPoint(x: size.width, y: 0)
            ),
            style: StrokeStyle(lineWidth: 3, lineCap: .round, lineJoin: .round)
        )
    }

    private func drawPlayhead(context: GraphicsContext, size: CGSize) {
        let x = graphPadding + ((size.width - graphPadding * 2) * CGFloat(currentProgress.clamped(to: 0...1)))
        var path = Path()
        path.move(to: CGPoint(x: x, y: graphPadding))
        path.addLine(to: CGPoint(x: x, y: size.height - graphPadding))
        context.stroke(path, with: .color(EditFlowTheme.accentPink.opacity(0.75)), lineWidth: 1)
    }

    private func position(for point: SpeedPoint, in size: CGSize) -> CGPoint {
        CGPoint(
            x: graphPadding + ((size.width - graphPadding * 2) * CGFloat(point.position)),
            y: y(forSpeed: point.speed, height: size.height)
        )
    }

    private func y(forSpeed speed: Double, height: CGFloat) -> CGFloat {
        let minSpeed = SpeedCurve.speedRange.lowerBound
        let maxSpeed = SpeedCurve.speedRange.upperBound
        let normalized = log(speed / minSpeed) / log(maxSpeed / minSpeed)
        return graphPadding + ((height - graphPadding * 2) * CGFloat(1 - normalized))
    }

    private func speed(fromY y: CGFloat, height: CGFloat) -> Double {
        let usable = max(height - graphPadding * 2, 1)
        let normalized = (1 - ((y - graphPadding) / usable)).clamped(to: 0...1)
        let minSpeed = SpeedCurve.speedRange.lowerBound
        let maxSpeed = SpeedCurve.speedRange.upperBound
        return minSpeed * pow(maxSpeed / minSpeed, Double(normalized))
    }

    private func progress(fromX x: CGFloat, width: CGFloat) -> Double {
        Double(((x - graphPadding) / max(width - graphPadding * 2, 1)).clamped(to: 0...1))
    }
}

private struct SpeedPresetButton: View {
    let label: String
    let speed: Double
    @Binding var curve: SpeedCurve

    var body: some View {
        Button(label) {
            curve = SpeedCurve(points: [
                SpeedPoint(position: 0, speed: speed),
                SpeedPoint(position: 1, speed: speed)
            ])
        }
        .font(.caption2.bold())
        .buttonStyle(.plain)
        .frame(maxWidth: .infinity)
        .padding(.vertical, 7)
        .background(.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 8))
    }
}
