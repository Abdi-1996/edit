import SwiftUI

private enum InspectorPanel: String, CaseIterable, Identifiable {
    case speed = "Скорость"
    case templates = "Шаблоны"
    case ai = "AI"

    var id: String { rawValue }
    var symbol: String {
        switch self {
        case .speed: "point.3.connected.trianglepath.dotted"
        case .templates: "square.grid.2x2.fill"
        case .ai: "wand.and.stars"
        }
    }
}

struct EditorInspectorView: View {
    @EnvironmentObject private var editor: EditorViewModel
    @State private var panel: InspectorPanel = .speed

    var body: some View {
        VStack(spacing: 12) {
            HStack(spacing: 6) {
                ForEach(InspectorPanel.allCases) { item in
                    Button {
                        withAnimation(.snappy) { panel = item }
                    } label: {
                        Label(item.rawValue, systemImage: item.symbol)
                            .font(.caption.bold())
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 9)
                            .background(
                                panel == item ? EditFlowTheme.accent.opacity(0.3) : .clear,
                                in: RoundedRectangle(cornerRadius: 9)
                            )
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(4)
            .background(.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 12))

            Group {
                switch panel {
                case .speed:
                    SpeedCurveEditorView(
                        curve: Binding(
                            get: { editor.selectedClip?.speedCurve ?? SpeedCurve() },
                            set: { editor.updateSpeedCurve($0) }
                        ),
                        currentProgress: editor.selectedProgress
                    )
                case .templates:
                    TemplatesView()
                case .ai:
                    AIEnhanceView()
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
            .opacity(editor.selectedClip == nil && panel != .ai ? 0.45 : 1)
        }
        .padding(14)
        .glassPanel(radius: 22)
    }
}

