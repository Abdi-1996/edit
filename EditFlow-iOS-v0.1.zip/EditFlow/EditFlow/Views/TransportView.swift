import SwiftUI

struct TransportView: View {
    @EnvironmentObject private var editor: EditorViewModel

    var body: some View {
        VStack(spacing: 8) {
            Slider(
                value: Binding(
                    get: { editor.selectedProgress },
                    set: { editor.seek(toProgress: $0) }
                ),
                in: 0...1
            )
            .tint(EditFlowTheme.accentPink)
            .disabled(editor.selectedClip == nil)

            HStack(spacing: 18) {
                Text(formatTime(editor.currentSourceTime))
                    .font(.caption.monospacedDigit())
                    .foregroundStyle(EditFlowTheme.textSecondary)
                    .frame(width: 70, alignment: .leading)

                Spacer()
                Button {
                    editor.seek(toProgress: max(0, editor.selectedProgress - 0.03))
                } label: {
                    Image(systemName: "backward.frame.fill")
                }
                .buttonStyle(.plain)

                Button {
                    editor.togglePlayback()
                } label: {
                    Image(systemName: editor.isPlaying ? "pause.fill" : "play.fill")
                        .font(.title3)
                        .frame(width: 46, height: 36)
                        .background(.white.opacity(0.1), in: Capsule())
                }
                .buttonStyle(.plain)

                Button {
                    editor.seek(toProgress: min(1, editor.selectedProgress + 0.03))
                } label: {
                    Image(systemName: "forward.frame.fill")
                }
                .buttonStyle(.plain)
                Spacer()

                Text(formatTime(editor.selectedClip?.trimEnd ?? 0))
                    .font(.caption.monospacedDigit())
                    .foregroundStyle(EditFlowTheme.textSecondary)
                    .frame(width: 70, alignment: .trailing)
            }
            .foregroundStyle(.white.opacity(0.9))
            .disabled(editor.selectedClip == nil)
        }
    }
}

