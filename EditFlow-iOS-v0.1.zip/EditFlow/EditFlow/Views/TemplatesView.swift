import SwiftUI

struct TemplatesView: View {
    @EnvironmentObject private var editor: EditorViewModel

    var body: some View {
        ScrollView {
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 145), spacing: 10)], spacing: 10) {
                ForEach(EditTemplate.builtIn) { template in
                    Button {
                        editor.applyTemplate(template)
                    } label: {
                        VStack(alignment: .leading, spacing: 10) {
                            HStack {
                                Image(systemName: template.symbol)
                                    .font(.title3.bold())
                                    .foregroundStyle(Color(hex: template.colorHex))
                                Spacer()
                                if editor.selectedClip?.speedCurve == template.curve {
                                    Image(systemName: "checkmark.circle.fill")
                                        .foregroundStyle(EditFlowTheme.cyan)
                                }
                            }
                            Text(template.name)
                                .font(.subheadline.bold())
                                .foregroundStyle(.white)
                            Text(template.subtitle)
                                .font(.caption2)
                                .foregroundStyle(EditFlowTheme.textSecondary)
                                .multilineTextAlignment(.leading)
                                .lineLimit(2)
                        }
                        .frame(maxWidth: .infinity, minHeight: 95, alignment: .leading)
                        .padding(12)
                        .background(
                            LinearGradient(
                                colors: [Color(hex: template.colorHex).opacity(0.2), .white.opacity(0.035)],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            ),
                            in: RoundedRectangle(cornerRadius: 14, style: .continuous)
                        )
                        .overlay {
                            RoundedRectangle(cornerRadius: 14, style: .continuous)
                                .stroke(Color(hex: template.colorHex).opacity(0.25))
                        }
                    }
                    .buttonStyle(.plain)
                    .disabled(editor.selectedClip == nil)
                }
            }

            VStack(alignment: .leading, spacing: 8) {
                Text("ЦВЕТОВОЙ СТИЛЬ")
                    .font(.caption.bold())
                    .foregroundStyle(EditFlowTheme.textSecondary)
                ForEach(EditLook.allCases, id: \.self) { look in
                    Button {
                        editor.setLook(look)
                    } label: {
                        HStack {
                            Image(systemName: "camera.filters")
                            Text(look.title)
                            Spacer()
                            if editor.selectedClip?.look == look {
                                Image(systemName: "checkmark")
                                    .foregroundStyle(EditFlowTheme.cyan)
                            }
                        }
                        .padding(10)
                        .background(.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 10))
                    }
                    .buttonStyle(.plain)
                    .disabled(editor.selectedClip == nil)
                }
            }
            .padding(.top, 12)
        }
    }
}

