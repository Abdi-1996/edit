import SwiftUI

enum EditFlowTheme {
    static let background = Color(hex: 0x090811)
    static let panel = Color(hex: 0x171522)
    static let panelRaised = Color(hex: 0x211E31)
    static let accent = Color(hex: 0x825BFF)
    static let accentPink = Color(hex: 0xFF4F9A)
    static let cyan = Color(hex: 0x3FD6FF)
    static let textSecondary = Color.white.opacity(0.58)
}

extension Color {
    init(hex: UInt, alpha: Double = 1) {
        self.init(
            .sRGB,
            red: Double((hex >> 16) & 0xff) / 255,
            green: Double((hex >> 8) & 0xff) / 255,
            blue: Double(hex & 0xff) / 255,
            opacity: alpha
        )
    }
}

struct GlassPanel: ViewModifier {
    var radius: CGFloat = 20

    func body(content: Content) -> some View {
        content
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: radius, style: .continuous))
            .overlay {
                RoundedRectangle(cornerRadius: radius, style: .continuous)
                    .stroke(Color.white.opacity(0.09), lineWidth: 1)
            }
    }
}

extension View {
    func glassPanel(radius: CGFloat = 20) -> some View {
        modifier(GlassPanel(radius: radius))
    }
}

