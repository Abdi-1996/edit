import SwiftUI
import UIKit

struct TimelineView: View {
    @EnvironmentObject private var editor: EditorViewModel

    var body: some View {
        VStack(spacing: 8) {
            HStack {
                Label("ТАЙМЛАЙН", systemImage: "timeline.selection")
                    .font(.caption.bold())
                    .foregroundStyle(EditFlowTheme.textSecondary)
                Spacer()
                Text(formatTime(editor.totalOutputDuration))
                    .font(.caption.monospacedDigit())
                    .foregroundStyle(EditFlowTheme.textSecondary)
            }

            if editor.project.clips.isEmpty {
                ContentUnavailableView(
                    "Пустой таймлайн",
                    systemImage: "film.stack",
                    description: Text("Добавьте видео из медиатеки")
                )
                .frame(height: 92)
            } else {
                ScrollView(.horizontal) {
                    HStack(spacing: 6) {
                        ForEach(editor.project.clips) { clip in
                            ClipCell(
                                clip: clip,
                                selected: editor.selectedClipID == clip.id,
                                playheadProgress: editor.selectedClipID == clip.id ? editor.selectedProgress : nil
                            )
                            .onTapGesture { editor.selectClip(clip.id) }
                        }
                    }
                    .padding(.vertical, 2)
                }
                .scrollIndicators(.hidden)
            }

            HStack(spacing: 10) {
                TimelineButton(symbol: "chevron.left", title: "Назад") { editor.moveSelected(by: -1) }
                TimelineButton(symbol: "scissors", title: "Разрезать") { editor.splitSelectedClip() }
                TimelineButton(
                    symbol: editor.selectedClip?.isMuted == true ? "speaker.slash.fill" : "speaker.wave.2.fill",
                    title: "Звук"
                ) { editor.toggleMute() }
                TimelineButton(symbol: "trash", title: "Удалить", role: .destructive) { editor.deleteSelectedClip() }
                TimelineButton(symbol: "chevron.right", title: "Вперёд") { editor.moveSelected(by: 1) }
            }
            .disabled(editor.selectedClip == nil)
        }
        .padding(12)
        .background(EditFlowTheme.panel.opacity(0.82), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
    }
}

private struct ClipCell: View {
    let clip: TimelineClip
    let selected: Bool
    let playheadProgress: Double?
    @State private var thumbnail: UIImage?

    private var width: CGFloat {
        CGFloat((clip.estimatedOutputDuration * 42).clamped(to: 92...260))
    }

    var body: some View {
        ZStack(alignment: .bottomLeading) {
            Group {
                if let thumbnail {
                    Image(uiImage: thumbnail)
                        .resizable()
                        .scaledToFill()
                } else {
                    LinearGradient(
                        colors: [EditFlowTheme.panelRaised, EditFlowTheme.accent.opacity(0.28)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                    .overlay { ProgressView().controlSize(.small) }
                }
            }
            .frame(width: width, height: 76)
            .clipped()

            LinearGradient(colors: [.clear, .black.opacity(0.78)], startPoint: .top, endPoint: .bottom)

            VStack(alignment: .leading, spacing: 2) {
                Text(clip.displayName)
                    .font(.caption2.bold())
                    .lineLimit(1)
                HStack(spacing: 4) {
                    Text(String(format: "%.1fs", clip.estimatedOutputDuration))
                    if clip.look != .clean {
                        Image(systemName: "camera.filters")
                    }
                }
                .font(.caption2.monospacedDigit())
                .foregroundStyle(.white.opacity(0.7))
            }
            .padding(7)

            if let playheadProgress {
                Rectangle()
                    .fill(EditFlowTheme.accentPink)
                    .frame(width: 2, height: 76)
                    .offset(x: (width - 2) * CGFloat(playheadProgress))
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
        .frame(width: width, height: 76)
        .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 10, style: .continuous)
                .stroke(selected ? EditFlowTheme.accentPink : .white.opacity(0.08), lineWidth: selected ? 2 : 1)
        }
        .task(id: clip.id) {
            thumbnail = await ThumbnailService.shared.image(for: clip)
        }
    }
}

private struct TimelineButton: View {
    let symbol: String
    let title: String
    var role: ButtonRole?
    let action: () -> Void

    var body: some View {
        Button(role: role, action: action) {
            VStack(spacing: 3) {
                Image(systemName: symbol)
                    .font(.system(size: 14, weight: .semibold))
                Text(title)
                    .font(.system(size: 9, weight: .medium))
            }
            .frame(maxWidth: .infinity)
            .frame(height: 38)
        }
        .buttonStyle(.plain)
        .foregroundStyle(role == .destructive ? .red : .white.opacity(0.82))
        .background(.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 9))
    }
}
