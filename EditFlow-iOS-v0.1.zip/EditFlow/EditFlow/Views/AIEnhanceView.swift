import SwiftUI
import UniformTypeIdentifiers

struct AIEnhanceView: View {
    @EnvironmentObject private var editor: EditorViewModel
    @StateObject private var ai = AIEnhanceViewModel()
    @State private var showWorkflowImporter = false

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                Label("AI Enhance через ComfyUI", systemImage: "wand.and.stars.inverse")
                    .font(.headline)

                Text("Видео обрабатывается мощной моделью на вашем ПК, а результат автоматически возвращается в таймлайн.")
                    .font(.caption)
                    .foregroundStyle(EditFlowTheme.textSecondary)

                VStack(alignment: .leading, spacing: 7) {
                    Text("АДРЕС COMFYUI")
                        .font(.caption2.bold())
                        .foregroundStyle(EditFlowTheme.textSecondary)
                    TextField("192.168.1.2:8188", text: $ai.serverAddress)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .keyboardType(.URL)
                        .padding(11)
                        .background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 10))
                }

                HStack(spacing: 10) {
                    Button {
                        Task { await ai.testConnection() }
                    } label: {
                        Label("Проверить", systemImage: "network")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(AISecondaryButtonStyle())

                    Button {
                        showWorkflowImporter = true
                    } label: {
                        Label("Workflow", systemImage: "doc.badge.plus")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(AISecondaryButtonStyle())
                }

                VStack(alignment: .leading, spacing: 4) {
                    Text("API workflow")
                        .font(.caption2)
                        .foregroundStyle(EditFlowTheme.textSecondary)
                    Text(ai.workflowName)
                        .font(.caption.bold())
                    Text("В Load Video укажите __INPUT_VIDEO__, а в filename_prefix — __OUTPUT_PREFIX__.")
                        .font(.caption2)
                        .foregroundStyle(EditFlowTheme.textSecondary)
                }
                .padding(11)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 10))

                HStack(spacing: 8) {
                    if ai.isWorking { ProgressView().controlSize(.small) }
                    Text(ai.status)
                        .font(.caption)
                        .foregroundStyle(ai.status.contains("подключён") ? EditFlowTheme.cyan : EditFlowTheme.textSecondary)
                }

                Button {
                    guard let clip = editor.selectedClip else { return }
                    Task {
                        if let result = await ai.enhance(clip: clip) {
                            await editor.addAIResult(url: result)
                        }
                    }
                } label: {
                    HStack {
                        if ai.isWorking {
                            ProgressView().tint(.white)
                        } else {
                            Image(systemName: "sparkles.rectangle.stack.fill")
                        }
                        Text(ai.isWorking ? "Обработка…" : "Улучшить выбранный клип")
                    }
                    .font(.subheadline.bold())
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
                    .background(
                        LinearGradient(
                            colors: [EditFlowTheme.accent, EditFlowTheme.accentPink],
                            startPoint: .leading,
                            endPoint: .trailing
                        ),
                        in: RoundedRectangle(cornerRadius: 12)
                    )
                }
                .buttonStyle(.plain)
                .disabled(editor.selectedClip == nil || ai.isWorking)
                .opacity(editor.selectedClip == nil ? 0.45 : 1)
            }
        }
        .fileImporter(
            isPresented: $showWorkflowImporter,
            allowedContentTypes: [.json],
            allowsMultipleSelection: false
        ) { result in
            guard case .success(let urls) = result, let url = urls.first else { return }
            Task { await ai.importWorkflow(from: url) }
        }
        .alert("AI Enhance", isPresented: Binding(
            get: { ai.errorMessage != nil },
            set: { if !$0 { ai.errorMessage = nil } }
        )) {
            Button("OK", role: .cancel) { ai.errorMessage = nil }
        } message: {
            Text(ai.errorMessage ?? "")
        }
    }
}

private struct AISecondaryButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.caption.bold())
            .padding(.vertical, 10)
            .foregroundStyle(.white.opacity(configuration.isPressed ? 0.55 : 0.9))
            .background(.white.opacity(configuration.isPressed ? 0.035 : 0.07), in: RoundedRectangle(cornerRadius: 10))
    }
}
