import Combine
import Foundation

@MainActor
final class AIEnhanceViewModel: ObservableObject {
    @Published var serverAddress: String {
        didSet { UserDefaults.standard.set(serverAddress, forKey: "comfyuiAddress") }
    }
    @Published private(set) var workflowName = "Не выбран"
    @Published private(set) var isWorking = false
    @Published private(set) var status = "Готов к подключению"
    @Published var errorMessage: String?

    init() {
        serverAddress = UserDefaults.standard.string(forKey: "comfyuiAddress") ?? "192.168.1.2:8188"
        Task {
            if await AIWorkflowStore.shared.load() != nil {
                workflowName = "Сохранённый API workflow"
            } else if let bundled = Bundle.main.url(forResource: "EnhanceWorkflow.example", withExtension: "json"),
                      let data = try? Data(contentsOf: bundled) {
                try? await AIWorkflowStore.shared.save(data)
                workflowName = "Video Enhance (пример)"
            }
        }
    }

    func importWorkflow(from url: URL) async {
        let hasAccess = url.startAccessingSecurityScopedResource()
        defer { if hasAccess { url.stopAccessingSecurityScopedResource() } }
        do {
            let data = try Data(contentsOf: url)
            try await AIWorkflowStore.shared.save(data)
            workflowName = url.lastPathComponent
            status = "Workflow импортирован"
        } catch {
            errorMessage = "Не удалось импортировать workflow: \(error.localizedDescription)"
        }
    }

    func testConnection() async {
        guard !isWorking else { return }
        isWorking = true
        status = "Проверяю соединение…"
        defer { isWorking = false }
        do {
            let client = try ComfyUIClient(address: serverAddress)
            try await client.testConnection()
            status = "ComfyUI подключён"
        } catch {
            status = "Нет соединения"
            errorMessage = error.localizedDescription
        }
    }

    func enhance(clip: TimelineClip) async -> URL? {
        guard !isWorking else { return nil }
        isWorking = true
        status = "Загружаю видео в ComfyUI…"
        defer { isWorking = false }
        do {
            guard let workflow = await AIWorkflowStore.shared.load() else {
                throw ComfyUIError.workflowMissing
            }
            let client = try ComfyUIClient(address: serverAddress)
            status = "AI-улучшение выполняется на ПК…"
            let url = try await client.enhance(videoURL: clip.sourceURL, workflowData: workflow)
            status = "Улучшенное видео загружено"
            return url
        } catch {
            status = "Обработка не завершена"
            errorMessage = error.localizedDescription
            return nil
        }
    }
}
