@preconcurrency import AVFoundation
import Combine
import Foundation
import Photos

@MainActor
final class EditorViewModel: ObservableObject {
    @Published private(set) var project = EditProject()
    @Published var selectedClipID: UUID?
    @Published private(set) var currentSourceTime: Double = 0
    @Published private(set) var isPlaying = false
    @Published private(set) var isImporting = false
    @Published private(set) var isExporting = false
    @Published var exportQuality: ExportQuality = .hd
    @Published var exportedURL: URL?
    @Published var message: String?

    let player = AVPlayer()
    private var timeObserver: Any?
    private let exporter = VideoExporter()

    var selectedClip: TimelineClip? {
        guard let selectedClipID else { return nil }
        return project.clips.first(where: { $0.id == selectedClipID })
    }

    var selectedProgress: Double {
        guard let clip = selectedClip, clip.trimmedDuration > 0 else { return 0 }
        return ((currentSourceTime - clip.trimStart) / clip.trimmedDuration).clamped(to: 0...1)
    }

    var totalOutputDuration: Double {
        project.clips.reduce(0) { $0 + $1.estimatedOutputDuration }
    }

    init() {
        installTimeObserver()
        Task {
            if let saved = await ProjectStore.shared.load() {
                project = saved
                selectedClipID = saved.clips.first?.id
                rebuildPlayer()
            }
        }
    }

    func importMovies(_ items: [ImportedMovie]) async {
        guard !items.isEmpty else { return }
        isImporting = true
        defer { isImporting = false }

        for item in items {
            do {
                let asset = AVURLAsset(url: item.url)
                let duration = try await asset.load(.duration).seconds
                guard duration.isFinite, duration > 0 else { continue }
                let clip = TimelineClip(
                    sourceURL: item.url,
                    displayName: item.url.deletingPathExtension().lastPathComponent,
                    sourceDuration: duration,
                    trimEnd: duration
                )
                project.clips.append(clip)
                selectedClipID = clip.id
            } catch {
                message = "Не удалось импортировать видео: \(error.localizedDescription)"
            }
        }
        project.updatedAt = Date()
        rebuildPlayer()
        save()
    }

    func selectClip(_ id: UUID) {
        guard project.clips.contains(where: { $0.id == id }) else { return }
        selectedClipID = id
        rebuildPlayer()
    }

    func togglePlayback() {
        guard let clip = selectedClip else { return }
        if isPlaying {
            player.pause()
            isPlaying = false
            return
        }
        if currentSourceTime >= clip.trimEnd - 0.03 {
            seek(toProgress: 0)
        }
        isPlaying = true
        let speed = Float(clip.speedCurve.speed(at: selectedProgress))
        player.playImmediately(atRate: speed)
    }

    func seek(toProgress progress: Double) {
        guard let clip = selectedClip else { return }
        let second = clip.trimStart + (clip.trimmedDuration * progress.clamped(to: 0...1))
        currentSourceTime = second
        player.seek(
            to: CMTime(seconds: second, preferredTimescale: 600),
            toleranceBefore: .zero,
            toleranceAfter: .zero
        )
    }

    func updateSpeedCurve(_ curve: SpeedCurve) {
        updateSelectedClip { $0.speedCurve = curve }
    }

    func applyTemplate(_ template: EditTemplate) {
        updateSelectedClip {
            $0.speedCurve = template.curve
            $0.look = template.look
        }
        message = "Шаблон «\(template.name)» применён"
    }

    func setLook(_ look: EditLook) {
        updateSelectedClip { $0.look = look }
    }

    func toggleMute() {
        updateSelectedClip { $0.isMuted.toggle() }
    }

    func splitSelectedClip() {
        guard let selectedClipID,
              let index = project.clips.firstIndex(where: { $0.id == selectedClipID }) else { return }
        let clip = project.clips[index]
        guard clip.trimmedDuration > 0.2 else {
            message = "Этот клип слишком короткий для разрезания"
            return
        }
        let split = currentSourceTime.clamped(to: (clip.trimStart + 0.08)...(clip.trimEnd - 0.08))
        guard split > clip.trimStart + 0.07, split < clip.trimEnd - 0.07 else {
            message = "Переместите курсор дальше от края клипа"
            return
        }

        var left = clip
        left.id = UUID()
        left.trimEnd = split
        var right = clip
        right.id = UUID()
        right.trimStart = split
        project.clips.replaceSubrange(index...index, with: [left, right])
        self.selectedClipID = right.id
        rebuildPlayer()
        save()
    }

    func deleteSelectedClip() {
        guard let selectedClipID,
              let index = project.clips.firstIndex(where: { $0.id == selectedClipID }) else { return }
        project.clips.remove(at: index)
        self.selectedClipID = project.clips.indices.contains(index)
            ? project.clips[index].id
            : project.clips.last?.id
        rebuildPlayer()
        save()
    }

    func moveSelected(by offset: Int) {
        guard let selectedClipID,
              let from = project.clips.firstIndex(where: { $0.id == selectedClipID }) else { return }
        let to = (from + offset).clamped(to: 0...max(project.clips.count - 1, 0))
        guard from != to else { return }
        let clip = project.clips.remove(at: from)
        project.clips.insert(clip, at: to)
        save()
    }

    func addAIResult(url: URL) async {
        await importMovies([ImportedMovie(url: url)])
    }

    func export() async {
        guard !isExporting else { return }
        isExporting = true
        exportedURL = nil
        do {
            let result = try await exporter.export(project: project, quality: exportQuality)
            exportedURL = result.url
            message = "Экспорт готов — \(formatTime(result.duration))"
        } catch {
            message = error.localizedDescription
        }
        isExporting = false
    }

    func saveExportToPhotos() async {
        guard let exportedURL else { return }
        do {
            let status = await PHPhotoLibrary.requestAuthorization(for: .addOnly)
            guard status == .authorized || status == .limited else {
                message = "Разрешите сохранение в «Фото» в настройках iOS"
                return
            }
            try await PHPhotoLibrary.shared().performChanges {
                PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: exportedURL)
            }
            message = "Видео сохранено в «Фото»"
        } catch {
            message = "Не удалось сохранить видео: \(error.localizedDescription)"
        }
    }

    func dismissMessage() {
        message = nil
    }

    private func updateSelectedClip(_ mutation: (inout TimelineClip) -> Void) {
        guard let selectedClipID,
              let index = project.clips.firstIndex(where: { $0.id == selectedClipID }) else { return }
        mutation(&project.clips[index])
        project.updatedAt = Date()
        save()
    }

    private func rebuildPlayer() {
        player.pause()
        isPlaying = false
        guard let clip = selectedClip else {
            player.replaceCurrentItem(with: nil)
            currentSourceTime = 0
            return
        }
        player.replaceCurrentItem(with: AVPlayerItem(url: clip.sourceURL))
        currentSourceTime = clip.trimStart
        seek(toProgress: 0)
    }

    private func installTimeObserver() {
        let interval = CMTime(seconds: 1.0 / 30.0, preferredTimescale: 600)
        timeObserver = player.addPeriodicTimeObserver(forInterval: interval, queue: .main) { [weak self] time in
            guard let self else { return }
            Task { @MainActor in
                guard let clip = self.selectedClip else { return }
                self.currentSourceTime = time.seconds
                if time.seconds >= clip.trimEnd {
                    self.player.pause()
                    self.isPlaying = false
                    self.seek(toProgress: 1)
                } else if self.isPlaying {
                    self.player.rate = Float(clip.speedCurve.speed(at: self.selectedProgress))
                }
            }
        }
    }

    private func save() {
        let snapshot = project
        Task { await ProjectStore.shared.save(snapshot) }
    }
}

func formatTime(_ seconds: Double) -> String {
    guard seconds.isFinite else { return "00:00.00" }
    let minutes = Int(seconds) / 60
    let remainder = seconds - Double(minutes * 60)
    return String(format: "%02d:%05.2f", minutes, remainder)
}
