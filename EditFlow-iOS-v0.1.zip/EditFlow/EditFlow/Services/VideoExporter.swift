@preconcurrency import AVFoundation
import CoreImage
import Foundation

enum VideoExportError: LocalizedError {
    case noClips
    case missingVideoTrack(String)
    case cannotCreateTrack
    case cannotCreateExporter
    case exportFailed(String)

    var errorDescription: String? {
        switch self {
        case .noClips: "Добавьте хотя бы один клип."
        case .missingVideoTrack(let name): "В файле «\(name)» не найден видеопоток."
        case .cannotCreateTrack: "Не удалось создать дорожку проекта."
        case .cannotCreateExporter: "Этот формат экспорта недоступен на устройстве."
        case .exportFailed(let message): "Ошибка экспорта: \(message)"
        }
    }
}

actor VideoExporter {
    struct Result: Sendable {
        let url: URL
        let duration: Double
    }

    func export(project: EditProject, quality: ExportQuality) async throws -> Result {
        guard !project.clips.isEmpty else { throw VideoExportError.noClips }

        let composition = AVMutableComposition()
        guard let compositionVideo = composition.addMutableTrack(
            withMediaType: .video,
            preferredTrackID: kCMPersistentTrackID_Invalid
        ) else { throw VideoExportError.cannotCreateTrack }
        let compositionAudio = composition.addMutableTrack(
            withMediaType: .audio,
            preferredTrackID: kCMPersistentTrackID_Invalid
        )

        var cursor = CMTime.zero
        var firstTransform: CGAffineTransform?

        for clip in project.clips {
            let asset = AVURLAsset(url: clip.sourceURL)
            guard let sourceVideo = try await asset.loadTracks(withMediaType: .video).first else {
                throw VideoExportError.missingVideoTrack(clip.displayName)
            }
            let sourceAudio = try await asset.loadTracks(withMediaType: .audio).first
            if firstTransform == nil {
                firstTransform = try await sourceVideo.load(.preferredTransform)
            }

            let fullRange = CMTimeRange(
                start: CMTime(seconds: clip.trimStart, preferredTimescale: 600),
                duration: CMTime(seconds: clip.trimmedDuration, preferredTimescale: 600)
            )
            let segmentCount = max(24, min(120, Int(clip.trimmedDuration * 12)))

            for index in 0..<segmentCount {
                let startRatio = Double(index) / Double(segmentCount)
                let endRatio = Double(index + 1) / Double(segmentCount)
                let sourceStart = fullRange.start + CMTime(
                    seconds: fullRange.duration.seconds * startRatio,
                    preferredTimescale: 600
                )
                let sourceDuration = CMTime(
                    seconds: fullRange.duration.seconds * (endRatio - startRatio),
                    preferredTimescale: 600
                )
                let sourceRange = CMTimeRange(start: sourceStart, duration: sourceDuration)
                let speed = clip.speedCurve.speed(at: (startRatio + endRatio) / 2)
                let outputDuration = CMTime(
                    seconds: sourceDuration.seconds / speed,
                    preferredTimescale: 600
                )

                let insertedVideoRange = CMTimeRange(start: cursor, duration: sourceDuration)
                try compositionVideo.insertTimeRange(sourceRange, of: sourceVideo, at: cursor)
                compositionVideo.scaleTimeRange(insertedVideoRange, toDuration: outputDuration)

                if !clip.isMuted, let sourceAudio, let compositionAudio {
                    do {
                        try compositionAudio.insertTimeRange(sourceRange, of: sourceAudio, at: cursor)
                        compositionAudio.scaleTimeRange(insertedVideoRange, toDuration: outputDuration)
                    } catch {
                        // Some phone videos have an audio stream shorter than the final frame.
                    }
                }
                cursor = cursor + outputDuration
            }
        }

        if let firstTransform {
            compositionVideo.preferredTransform = firstTransform
        }

        let look = project.clips.first?.look ?? .clean
        let videoComposition = makeFilterComposition(asset: composition, look: look)
        let preset = quality == .ultraHD
            ? AVAssetExportPresetHEVC3840x2160
            : AVAssetExportPresetHighestQuality

        guard let session = AVAssetExportSession(asset: composition, presetName: preset) else {
            throw VideoExportError.cannotCreateExporter
        }
        let directory = try MediaImportService.exportsDirectory()
        let outputURL = directory
            .appendingPathComponent("EditFlow-\(Int(Date().timeIntervalSince1970))")
            .appendingPathExtension("mp4")
        try? FileManager.default.removeItem(at: outputURL)

        session.outputURL = outputURL
        session.outputFileType = .mp4
        session.shouldOptimizeForNetworkUse = true
        session.videoComposition = videoComposition

        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            session.exportAsynchronously {
                switch session.status {
                case .completed:
                    continuation.resume()
                case .failed, .cancelled:
                    continuation.resume(throwing: VideoExportError.exportFailed(
                        session.error?.localizedDescription ?? "операция отменена"
                    ))
                default:
                    continuation.resume(throwing: VideoExportError.exportFailed("неизвестное состояние"))
                }
            }
        }
        return Result(url: outputURL, duration: cursor.seconds)
    }

    private func makeFilterComposition(asset: AVAsset, look: EditLook) -> AVVideoComposition? {
        guard look != .clean else { return nil }
        return AVVideoComposition(asset: asset, applyingCIFiltersWithHandler: { request in
            var image = request.sourceImage.clampedToExtent()
            switch look {
            case .clean:
                break
            case .animePunch:
                image = image
                    .applyingFilter("CIColorControls", parameters: [
                        kCIInputContrastKey: 1.22,
                        kCIInputSaturationKey: 1.18,
                        kCIInputBrightnessKey: 0.015
                    ])
                    .applyingFilter("CISharpenLuminance", parameters: ["inputSharpness": 0.55])
            case .coldVelocity:
                image = image
                    .applyingFilter("CIColorControls", parameters: [
                        kCIInputContrastKey: 1.1,
                        kCIInputSaturationKey: 0.92
                    ])
                    .applyingFilter("CITemperatureAndTint", parameters: [
                        "inputNeutral": CIVector(x: 6500, y: 0),
                        "inputTargetNeutral": CIVector(x: 8200, y: 0)
                    ])
            case .warmGlow:
                image = image
                    .applyingFilter("CIColorControls", parameters: [
                        kCIInputContrastKey: 1.08,
                        kCIInputSaturationKey: 1.12,
                        kCIInputBrightnessKey: 0.02
                    ])
                    .applyingFilter("CITemperatureAndTint", parameters: [
                        "inputNeutral": CIVector(x: 6500, y: 0),
                        "inputTargetNeutral": CIVector(x: 5200, y: 0)
                    ])
            case .monochrome:
                image = image
                    .applyingFilter("CIPhotoEffectNoir")
                    .applyingFilter("CIColorControls", parameters: [kCIInputContrastKey: 1.25])
            }
            request.finish(with: image.cropped(to: request.sourceImage.extent), context: nil)
        })
    }
}
