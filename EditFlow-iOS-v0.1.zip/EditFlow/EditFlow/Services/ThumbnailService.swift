import AVFoundation
import UIKit

actor ThumbnailService {
    static let shared = ThumbnailService()
    private let cache = NSCache<NSString, UIImage>()

    func image(for clip: TimelineClip, at progress: Double = 0.5) async -> UIImage? {
        let key = "\(clip.id.uuidString)-\(Int(progress * 100))" as NSString
        if let cached = cache.object(forKey: key) { return cached }

        let asset = AVURLAsset(url: clip.sourceURL)
        let generator = AVAssetImageGenerator(asset: asset)
        generator.appliesPreferredTrackTransform = true
        generator.maximumSize = CGSize(width: 360, height: 360)
        let second = clip.trimStart + (clip.trimmedDuration * progress.clamped(to: 0...1))
        let time = CMTime(seconds: second, preferredTimescale: 600)

        do {
            let (cgImage, _) = try await generator.image(at: time)
            let image = UIImage(cgImage: cgImage)
            cache.setObject(image, forKey: key)
            return image
        } catch {
            return nil
        }
    }
}

