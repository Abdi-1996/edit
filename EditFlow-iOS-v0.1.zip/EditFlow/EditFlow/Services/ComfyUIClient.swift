import Foundation

enum ComfyUIError: LocalizedError {
    case invalidAddress
    case badResponse
    case server(String)
    case workflowMissing
    case outputMissing
    case timeout

    var errorDescription: String? {
        switch self {
        case .invalidAddress: "Проверьте адрес ComfyUI."
        case .badResponse: "ComfyUI вернул некорректный ответ."
        case .server(let message): "ComfyUI: \(message)"
        case .workflowMissing: "Импортируйте workflow в формате API JSON."
        case .outputMissing: "Workflow завершился, но видео не найдено в output."
        case .timeout: "ComfyUI не завершил обработку за отведённое время."
        }
    }
}

actor ComfyUIClient {
    struct OutputFile: Sendable {
        let filename: String
        let subfolder: String
        let type: String
    }

    private let baseURL: URL
    private let session: URLSession
    private let clientID = UUID().uuidString

    init(address: String) throws {
        var normalized = address.trimmingCharacters(in: .whitespacesAndNewlines)
        if !normalized.hasPrefix("http://") && !normalized.hasPrefix("https://") {
            normalized = "http://" + normalized
        }
        guard let url = URL(string: normalized), url.host != nil else {
            throw ComfyUIError.invalidAddress
        }
        self.baseURL = url
        let configuration = URLSessionConfiguration.default
        configuration.timeoutIntervalForRequest = 120
        configuration.timeoutIntervalForResource = 60 * 60
        self.session = URLSession(configuration: configuration)
    }

    func testConnection() async throws {
        let url = endpoint("system_stats")
        let (_, response) = try await session.data(from: url)
        try validate(response)
    }

    func enhance(videoURL: URL, workflowData: Data) async throws -> URL {
        let uploadedName = try await upload(videoURL)
        let promptID = try await queue(
            workflowData: workflowData,
            inputFilename: uploadedName,
            outputPrefix: "EditFlow/AI-\(Int(Date().timeIntervalSince1970))"
        )
        let output = try await waitForOutput(promptID: promptID)
        return try await download(output)
    }

    private func upload(_ fileURL: URL) async throws -> String {
        let boundary = "EditFlow-\(UUID().uuidString)"
        var request = URLRequest(url: endpoint("upload/image"))
        request.httpMethod = "POST"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")

        let data = try Data(contentsOf: fileURL)
        var body = Data()
        body.appendUTF8("--\(boundary)\r\n")
        body.appendUTF8("Content-Disposition: form-data; name=\"image\"; filename=\"\(fileURL.lastPathComponent)\"\r\n")
        body.appendUTF8("Content-Type: video/mp4\r\n\r\n")
        body.append(data)
        body.appendUTF8("\r\n--\(boundary)\r\n")
        body.appendUTF8("Content-Disposition: form-data; name=\"type\"\r\n\r\ninput\r\n")
        body.appendUTF8("--\(boundary)\r\n")
        body.appendUTF8("Content-Disposition: form-data; name=\"overwrite\"\r\n\r\ntrue\r\n")
        body.appendUTF8("--\(boundary)--\r\n")
        request.httpBody = body

        let (responseData, response) = try await session.data(for: request)
        try validate(response)
        guard let json = try JSONSerialization.jsonObject(with: responseData) as? [String: Any],
              let name = json["name"] as? String else {
            throw ComfyUIError.badResponse
        }
        return name
    }

    private func queue(
        workflowData: Data,
        inputFilename: String,
        outputPrefix: String
    ) async throws -> String {
        var workflow = try JSONSerialization.jsonObject(with: workflowData)
        workflow = replacingPlaceholders(
            in: workflow,
            values: [
                "__INPUT_VIDEO__": inputFilename,
                "__OUTPUT_PREFIX__": outputPrefix
            ]
        )
        let payload: [String: Any] = [
            "prompt": workflow,
            "client_id": clientID
        ]
        var request = URLRequest(url: endpoint("prompt"))
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONSerialization.data(withJSONObject: payload)

        let (data, response) = try await session.data(for: request)
        try validate(response, responseData: data)
        guard let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              let promptID = json["prompt_id"] as? String else {
            throw ComfyUIError.badResponse
        }
        return promptID
    }

    private func waitForOutput(promptID: String) async throws -> OutputFile {
        for _ in 0..<1800 {
            try await Task.sleep(for: .seconds(1))
            let (data, response) = try await session.data(from: endpoint("history/\(promptID)"))
            try validate(response, responseData: data)
            guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
                continue
            }
            guard let job = root[promptID] as? [String: Any] else { continue }

            if let status = job["status"] as? [String: Any],
               let completed = status["completed"] as? Bool,
               completed == false,
               let messages = status["messages"] as? [[Any]],
               messages.contains(where: { ($0.first as? String) == "execution_error" }) {
                throw ComfyUIError.server("ошибка выполнения workflow")
            }

            if let outputs = job["outputs"], let file = findVideoOutput(in: outputs) {
                return file
            }
            if job["outputs"] != nil {
                throw ComfyUIError.outputMissing
            }
        }
        throw ComfyUIError.timeout
    }

    private func download(_ output: OutputFile) async throws -> URL {
        var components = URLComponents(url: endpoint("view"), resolvingAgainstBaseURL: false)
        components?.queryItems = [
            URLQueryItem(name: "filename", value: output.filename),
            URLQueryItem(name: "subfolder", value: output.subfolder),
            URLQueryItem(name: "type", value: output.type)
        ]
        guard let url = components?.url else { throw ComfyUIError.badResponse }
        let (temporaryURL, response) = try await session.download(from: url)
        try validate(response)

        let directory = try MediaImportService.importsDirectory()
        let ext = (output.filename as NSString).pathExtension.isEmpty ? "mp4" : (output.filename as NSString).pathExtension
        let destination = directory
            .appendingPathComponent("AI-Enhanced-\(Int(Date().timeIntervalSince1970))")
            .appendingPathExtension(ext)
        try? FileManager.default.removeItem(at: destination)
        try FileManager.default.moveItem(at: temporaryURL, to: destination)
        return destination
    }

    private func endpoint(_ path: String) -> URL {
        path.split(separator: "/").reduce(baseURL) { partial, component in
            partial.appendingPathComponent(String(component))
        }
    }

    private func validate(_ response: URLResponse, responseData: Data? = nil) throws {
        guard let http = response as? HTTPURLResponse else { throw ComfyUIError.badResponse }
        guard (200..<300).contains(http.statusCode) else {
            let text = responseData.flatMap { String(data: $0, encoding: .utf8) }
            throw ComfyUIError.server(text ?? "HTTP \(http.statusCode)")
        }
    }

    private func replacingPlaceholders(in value: Any, values: [String: String]) -> Any {
        if let string = value as? String {
            return values.reduce(string) { result, item in
                result.replacingOccurrences(of: item.key, with: item.value)
            }
        }
        if let array = value as? [Any] {
            return array.map { replacingPlaceholders(in: $0, values: values) }
        }
        if let dictionary = value as? [String: Any] {
            return dictionary.mapValues { replacingPlaceholders(in: $0, values: values) }
        }
        return value
    }

    private func findVideoOutput(in value: Any) -> OutputFile? {
        if let dictionary = value as? [String: Any] {
            if let filename = dictionary["filename"] as? String,
               ["mp4", "mov", "webm", "mkv"].contains((filename as NSString).pathExtension.lowercased()) {
                return OutputFile(
                    filename: filename,
                    subfolder: dictionary["subfolder"] as? String ?? "",
                    type: dictionary["type"] as? String ?? "output"
                )
            }
            for nested in dictionary.values {
                if let output = findVideoOutput(in: nested) { return output }
            }
        }
        if let array = value as? [Any] {
            for nested in array {
                if let output = findVideoOutput(in: nested) { return output }
            }
        }
        return nil
    }
}

private extension Data {
    mutating func appendUTF8(_ string: String) {
        append(Data(string.utf8))
    }
}

