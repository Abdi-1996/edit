import Foundation

actor ProjectStore {
    static let shared = ProjectStore()

    private var projectURL: URL? {
        guard let support = try? FileManager.default.url(
            for: .applicationSupportDirectory,
            in: .userDomainMask,
            appropriateFor: nil,
            create: true
        ) else { return nil }
        let directory = support.appendingPathComponent("EditFlow", isDirectory: true)
        try? FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        return directory.appendingPathComponent("current-project.json")
    }

    func load() -> EditProject? {
        guard let projectURL,
              let data = try? Data(contentsOf: projectURL) else { return nil }
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return try? decoder.decode(EditProject.self, from: data)
    }

    func save(_ project: EditProject) {
        guard let projectURL,
              let data = try? JSONEncoder.pretty.encode(project) else { return }
        try? data.write(to: projectURL, options: .atomic)
    }
}

private extension JSONEncoder {
    static var pretty: JSONEncoder {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        encoder.dateEncodingStrategy = .iso8601
        return encoder
    }
}
