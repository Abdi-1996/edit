import Foundation

actor AIWorkflowStore {
    static let shared = AIWorkflowStore()

    private var url: URL? {
        guard let support = try? FileManager.default.url(
            for: .applicationSupportDirectory,
            in: .userDomainMask,
            appropriateFor: nil,
            create: true
        ) else { return nil }
        let directory = support.appendingPathComponent("EditFlow", isDirectory: true)
        try? FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        return directory.appendingPathComponent("ai-enhance-workflow.json")
    }

    func save(_ data: Data) throws {
        guard let url else { throw ComfyUIError.workflowMissing }
        _ = try JSONSerialization.jsonObject(with: data)
        try data.write(to: url, options: .atomic)
    }

    func load() -> Data? {
        guard let url else { return nil }
        return try? Data(contentsOf: url)
    }
}

