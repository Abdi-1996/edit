import Foundation

enum EditLook: String, Codable, CaseIterable, Sendable {
    case clean
    case animePunch
    case coldVelocity
    case warmGlow
    case monochrome

    var title: String {
        switch self {
        case .clean: "Clean"
        case .animePunch: "Anime Punch"
        case .coldVelocity: "Cold Velocity"
        case .warmGlow: "Warm Glow"
        case .monochrome: "B&W Impact"
        }
    }
}

struct TimelineClip: Identifiable, Codable, Equatable, Sendable {
    var id: UUID = UUID()
    var sourceURL: URL
    var displayName: String
    var sourceDuration: Double
    var trimStart: Double = 0
    var trimEnd: Double
    var speedCurve: SpeedCurve = SpeedCurve()
    var look: EditLook = .clean
    var isMuted = false

    var trimmedDuration: Double {
        max(0, trimEnd - trimStart)
    }

    var estimatedOutputDuration: Double {
        let samples = 48
        let sourceStep = trimmedDuration / Double(samples)
        return (0..<samples).reduce(0) { result, index in
            let progress = (Double(index) + 0.5) / Double(samples)
            return result + sourceStep / max(speedCurve.speed(at: progress), 0.1)
        }
    }
}

struct EditProject: Codable, Sendable {
    var id: UUID = UUID()
    var name = "Новый эдит"
    var clips: [TimelineClip] = []
    var createdAt = Date()
    var updatedAt = Date()
}

enum ExportQuality: String, CaseIterable, Identifiable, Sendable {
    case hd = "1080p"
    case ultraHD = "4K"

    var id: String { rawValue }
}

