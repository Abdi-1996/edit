import Foundation

struct EditTemplate: Identifiable, Hashable, Sendable {
    let id: String
    let name: String
    let subtitle: String
    let symbol: String
    let colorHex: UInt
    let curve: SpeedCurve
    let look: EditLook

    static let builtIn: [EditTemplate] = [
        EditTemplate(
            id: "phonk-impact",
            name: "Phonk Impact",
            subtitle: "Резкий разгон → стоп → удар",
            symbol: "bolt.fill",
            colorHex: 0xFF4F9A,
            curve: SpeedCurve(points: [
                SpeedPoint(position: 0.00, speed: 1.0),
                SpeedPoint(position: 0.14, speed: 2.8),
                SpeedPoint(position: 0.30, speed: 0.25),
                SpeedPoint(position: 0.43, speed: 0.18),
                SpeedPoint(position: 0.58, speed: 4.2),
                SpeedPoint(position: 0.78, speed: 0.65),
                SpeedPoint(position: 1.00, speed: 1.0)
            ]),
            look: .animePunch
        ),
        EditTemplate(
            id: "anime-flow",
            name: "Anime Flow",
            subtitle: "Плавная velocity-кривая для аниме",
            symbol: "sparkles",
            colorHex: 0x8B5CFF,
            curve: SpeedCurve(points: [
                SpeedPoint(position: 0.00, speed: 0.75),
                SpeedPoint(position: 0.22, speed: 0.35),
                SpeedPoint(position: 0.47, speed: 2.2),
                SpeedPoint(position: 0.70, speed: 0.48),
                SpeedPoint(position: 0.88, speed: 1.45),
                SpeedPoint(position: 1.00, speed: 0.9)
            ]),
            look: .coldVelocity
        ),
        EditTemplate(
            id: "smooth-velocity",
            name: "Smooth Velocity",
            subtitle: "Мягкое ускорение без рывков",
            symbol: "waveform.path.ecg",
            colorHex: 0x3FD6FF,
            curve: SpeedCurve(points: [
                SpeedPoint(position: 0.00, speed: 0.6),
                SpeedPoint(position: 0.25, speed: 0.85),
                SpeedPoint(position: 0.52, speed: 1.9),
                SpeedPoint(position: 0.78, speed: 0.82),
                SpeedPoint(position: 1.00, speed: 0.6)
            ]),
            look: .warmGlow
        ),
        EditTemplate(
            id: "manga-hit",
            name: "Manga Hit",
            subtitle: "Контрастный удар и короткая пауза",
            symbol: "burst.fill",
            colorHex: 0xF2F2F7,
            curve: SpeedCurve(points: [
                SpeedPoint(position: 0.00, speed: 1.4),
                SpeedPoint(position: 0.38, speed: 2.8),
                SpeedPoint(position: 0.48, speed: 0.12),
                SpeedPoint(position: 0.58, speed: 0.12),
                SpeedPoint(position: 0.72, speed: 3.2),
                SpeedPoint(position: 1.00, speed: 1.0)
            ]),
            look: .monochrome
        )
    ]
}
