import Foundation

struct SpeedPoint: Identifiable, Codable, Hashable, Sendable {
    var id: UUID = UUID()
    var position: Double
    var speed: Double

    init(id: UUID = UUID(), position: Double, speed: Double) {
        self.id = id
        self.position = position.clamped(to: 0...1)
        self.speed = speed.clamped(to: SpeedCurve.speedRange)
    }
}

struct SpeedCurve: Codable, Equatable, Hashable, Sendable {
    static let speedRange = 0.1...8.0

    var points: [SpeedPoint]

    init(points: [SpeedPoint] = [
        SpeedPoint(position: 0, speed: 1),
        SpeedPoint(position: 1, speed: 1)
    ]) {
        self.points = Self.normalized(points)
    }

    func speed(at progress: Double) -> Double {
        let x = progress.clamped(to: 0...1)
        guard let first = points.first, let last = points.last else { return 1 }
        if x <= first.position { return first.speed }
        if x >= last.position { return last.speed }

        for pair in zip(points, points.dropFirst()) {
            let (left, right) = pair
            guard x >= left.position, x <= right.position else { continue }
            let width = max(right.position - left.position, 0.0001)
            let t = (x - left.position) / width
            return left.speed + ((right.speed - left.speed) * t)
        }
        return 1
    }

    mutating func update(id: UUID, position: Double, speed: Double) {
        guard let index = points.firstIndex(where: { $0.id == id }) else { return }
        let isFirst = index == points.startIndex
        let isLast = index == points.index(before: points.endIndex)
        let lower = isFirst ? 0 : points[index - 1].position + 0.025
        let upper = isLast ? 1 : points[index + 1].position - 0.025

        points[index].position = isFirst ? 0 : (isLast ? 1 : position.clamped(to: lower...upper))
        points[index].speed = speed.clamped(to: Self.speedRange)
    }

    mutating func addPoint(position: Double, speed: Double) {
        guard points.count < 12 else { return }
        points.append(SpeedPoint(position: position, speed: speed))
        points = Self.normalized(points)
    }

    mutating func removePoint(id: UUID) {
        guard points.count > 2,
              let index = points.firstIndex(where: { $0.id == id }),
              index != points.startIndex,
              index != points.index(before: points.endIndex) else { return }
        points.remove(at: index)
    }

    private static func normalized(_ points: [SpeedPoint]) -> [SpeedPoint] {
        var result = points
            .map { SpeedPoint(id: $0.id, position: $0.position, speed: $0.speed) }
            .sorted { $0.position < $1.position }

        if result.count < 2 {
            result = [SpeedPoint(position: 0, speed: 1), SpeedPoint(position: 1, speed: 1)]
        }
        result[0].position = 0
        result[result.count - 1].position = 1
        return result
    }
}

extension Comparable {
    func clamped(to limits: ClosedRange<Self>) -> Self {
        min(max(self, limits.lowerBound), limits.upperBound)
    }
}
